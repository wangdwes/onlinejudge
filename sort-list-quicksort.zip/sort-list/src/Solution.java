
public class Solution {
    
	// helper class to return references to two nodes. 
	public class PairNode {
		ListNode first;
		ListNode second;
		PairNode() { first = null; second = null; }
		PairNode(ListNode pf, ListNode ps) { first = pf; second = ps; } }
	
	public ListNode sortList(ListNode head) {
		if (head == null) return head; // don't bother to sort an empty linked list. 
		
		ListNode tail = head; // find the tail for this linked list.
		while (tail.next != null)
			tail = tail.next; 
		
		// perform a quick-sort to meet nlgn complexity.  
		return quicksort(head, tail); 
	}
	
	public ListNode quicksort(ListNode head, ListNode tail) {
		if (head == tail) return head; // hopefully we're dealing with more than one node. 
		
		PairNode part = partition(head, tail); // part has settled its place after this invocation.
		if (part.second != tail) quicksort(part.second.next, tail); // nodes after part? sort them.
		if (part.first != null && part.first != head) quicksort(head, part.first);
		
		return head;
	}
	
	public PairNode partition(ListNode head, ListNode tail) {
		ListNode pivotNode = tail, storeNode = head, prvNode = null;
		int pivotValue = pivotNode.val;
		while (head != tail) {
			if (head.val <= pivotValue) {
				int tp = head.val; head.val = storeNode.val; storeNode.val = tp;
				prvNode = storeNode; storeNode = storeNode.next; }
			head = head.next; }
		
		int tp = storeNode.val; storeNode.val = tail.val; tail.val = tp;
		return new PairNode(prvNode, storeNode);
	}
    
}	