

public class Launcher {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String[] L = new String[2];
		L[0] = "foo";
		L[1] = "bar";
		
		Solution sol = new Solution();
		sol.findSubstring("bbbfoobarfoobarman", L);
		
		
	}

}
