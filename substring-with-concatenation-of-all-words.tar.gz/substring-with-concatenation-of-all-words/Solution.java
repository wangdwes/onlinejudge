import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class Solution {
    public List<Integer> findSubstring(String S, String[] L) {
    	List<Integer> indices = new ArrayList<Integer>();
    	if (L.length == 0) return indices;
    	
    	// Some word has been found multiple times!
    	Map<String, Integer> hasFound = new HashMap<String, Integer>();
    	
    	// Convert the plain array to a nice list... making life easier. 
    	List<String> words = new ArrayList<String>();
    	for (int index = 0; index < L.length; index++) { 
    		words.add(L[index]); hasFound.put(L[index], 0); }

    	int wordLength = L[0].length(), count = 0;    	
    	for (int begin = 0, end = 0; end < S.length() - wordLength; ) {
    		String substring = S.substring(end, end + wordLength); 
    		if (words.contains(substring)) {
    			hasFound.put(substring, hasFound.get(substring) + 1);
    			if (hasFound.get(substring) <= 1) count++;
    			else { if (count == L.length) { System.out.println(begin); }
    				while (begin <= end) {
    					String s = S.substring(begin, begin + wordLength);
    					hasFound.put(s, hasFound.get(s) - 1); begin += wordLength;
    					if (hasFound.get(s) == 0) count--; else break;
    				} 
    			}
    			end += wordLength;
    		} else {
    			begin = ++end; Iterator<String> iterator = words.iterator();
    			while (iterator.hasNext()) hasFound.put(iterator.next(), 0); 
    		}
    	}
    	
    	return null;
    	
    }
}
